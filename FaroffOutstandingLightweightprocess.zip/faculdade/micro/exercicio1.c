#include<stdio.h>
#include <stdint.h>

#define SQUARE(n) (printf("%d",n*n))

int main(){
    int num;
    scanf("%d",&num);
    SQUARE(num);
    return 0;
}
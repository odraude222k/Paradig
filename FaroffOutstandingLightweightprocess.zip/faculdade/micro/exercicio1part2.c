#include<stdio.h>
#include<stdint.h>

#define MOTOR1  0b000000001
#define MOTOR2  0b000000010
#define MOTOR3  0b000000100
#define MOTOR4  0b000001000
#define MOTOR5  0b000010000

int main(){
        
    return 0;
}
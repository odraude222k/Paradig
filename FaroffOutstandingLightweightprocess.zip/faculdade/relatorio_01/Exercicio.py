class Professor:
    def __init__(self,nome):
        self.nome = nome
    
    def ministrar_aula(self, assunto):
        print("Professor ", self.nome, " está ministrando aula ",self.assunto)

class Aluno:
    def __init__(self,nome):
        self.nome = nome

    def presenca(self):
        print("O aluno ", self.nome, " esta presente")

class Aula:
    def __init__(self,professor,assunto,alunos):
        self.professor = professor
        self.assunto = assunto
        self.alunos = alunos
    
    def adicionar_aluno(self,aluno):
        self.alunos.append(aluno.nome)
    
    def listar_presenca(self):
        print("Presenca na aula ", self.assunto, " ministrada pelo professor ", self.professor.nome)

        for nome_aluno in alunos:
            print("O aluno ", nome_aluno, " esta presente")

professor = Professor("Lucas")
aluno1 = Aluno("Maria")
aluno2 = Aluno("Lucas")
alunos = []
aula = Aula(professor,"Programação orientada a objetos",alunos)
aula.adicionar_aluno(aluno1)
aula.adicionar_aluno(aluno2)
print(aula.listar_presenca())

        
        


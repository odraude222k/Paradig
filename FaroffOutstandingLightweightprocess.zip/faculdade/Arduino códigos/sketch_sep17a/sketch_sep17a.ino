#define LED1 (1<<PD5)
#define LED2 (1<<PD4)
#define BOTAO (1<<PD2)
#define BOTAO2 (1<<PD3)

int INT_cont = 0;
int INT0_enabled = 1;  // Variável para controlar o estado da interrupção INT0

int main(void){
  DDRD |= (LED1|LED2);
  PORTD &= ~(LED1 | LED2);

  PORTD |= BOTAO;   // Pull-up no botão ligado ao PD2 (INT0)
  PORTD |= BOTAO2;  // Pull-up no botão ligado ao PD3 (INT1)

  // Configuração de interrupção INT0 para borda de subida
  EICRA |= (1<<ISC01) | (1<<ISC00);
  // Configuração de interrupção INT1 para borda de descida
  EICRA |= (1<<ISC11);
  EICRA &= ~(1<<ISC10); // Apenas transição de descida para INT1
  
  EIMSK |= (1<<INT0) | (1<<INT1);  // Habilita INT0 e INT1

  sei();  // Habilita interrupções globais

  for(;;){

    if(INT_cont == 0){
      PORTD ^= LED1;  // Inverte o estado do LED1
      _delay_ms(500);
    }

    if(INT_cont == 1){
      INT_cont = 0;
      PORTD |= LED2;
      _delay_ms(1000);
      PORTD &= ~LED2;
    }
  }
}

// Interrupção INT0 (botão no PD2)
ISR(INT0_vect){
  if (INT0_enabled) {
    INT_cont = 1;
  }
}

// Interrupção INT1 (botão no PD3)
ISR(INT1_vect){
  if (INT0_enabled) {
    EIMSK &= ~(1<<INT0);  // Desabilita a interrupção INT0
    INT0_enabled = 0;
  } else {
    EIMSK |= (1<<INT0);   // Habilita a interrupção INT0
    INT0_enabled = 1;
  }
}

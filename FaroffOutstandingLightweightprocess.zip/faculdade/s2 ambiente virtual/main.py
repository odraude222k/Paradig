from pymongo import MongoClient


connector = MongoClient("mongodb://localhost:27017")

database = connector['countries']

collection = database.countries

result = collection.find()

print(result)
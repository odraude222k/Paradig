public class app {
    public static void main(String[] args){
        zumbi z = new zumbi();

        z.forca = 100;
        z.vida = 200;
        z.altura = 1.50f;
        z.nome = "Chris";

        zumbi z2 = new zumbi();
        z2.nome = "Lara";

        System.out.println("O nome do zumbi é: " + z.nome);
        System.out.println("O nome do zumbi2 é: " + z2.nome);

        z.andar();
        z.seAlimentar();

        z.iniciar();

        System.out.println("O nome do zumbi é: "+z.nome);


    }
}

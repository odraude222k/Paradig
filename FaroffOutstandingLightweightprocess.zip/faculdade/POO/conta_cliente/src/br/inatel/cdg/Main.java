package br.inatel.cdg;

public class Main {
    public static void main(String[] args) {

        Cliente c1 = new Cliente("dudu",1111111);
        Cliente c2 = new Cliente("Gabriel", 222222);
        Cliente c3 = null;

        Conta conta1 = new Conta(1,2000,5000);

        conta1.addCliente(c1);
        conta1.addCliente(c2);
        conta1.addCliente(c3);

        conta1.mostraInfo();







    }
}

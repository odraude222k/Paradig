package br.inatel.cdg;

public class SaldoInsuficienteExceptions extends RuntimeException{

    public SaldoInsuficienteExceptions(String mensagem ){
        super(mensagem);
    }
}

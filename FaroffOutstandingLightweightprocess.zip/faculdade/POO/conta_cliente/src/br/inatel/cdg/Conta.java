package br.inatel.cdg;

import java.util.HashSet;
import java.util.Set;

public class Conta {
    private int numero;
    private float saldo;
    private float limite;
    private Set<Cliente> clientes = new HashSet<>();

    public Conta(int numero, float saldo, float limite) {
        this.numero = numero;
        this.saldo = saldo;
        this.limite = limite;
    }

    public void addCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public float getSaldo() {
        return saldo;
    }

    public void sacar(float quantia) {
        if (saldo >= quantia && quantia <= limite) {
            saldo -= quantia;
            System.out.println("Saque realizado");
        } else if(quantia > limite) {
            throw  new SaldoInsuficienteExceptions("Limite atingido");
        } else if(saldo < quantia ) {
            throw new SaldoInsuficienteExceptions("Saque maior que o saldo");
        }
    }

    public void deposita(float quantia) {

        saldo += quantia;
    }

    public void mostraInfo() {
        System.out.println("Saldo: " + this.saldo);
        System.out.println("Numero da conta: " + this.numero);
        System.out.println("Limite da conta: " + this.limite);
        for (Cliente c : clientes) {
            try {
                System.out.println("Nome do cliente: " + c.getNome());
                System.out.println("Cpf do cliente: " + c.getCpf());
            } catch (NullPointerException e) {
                System.out.println("Erro " + e);
            }
        }
    }
}

public abstract class Classeai implements Comparable<Classeai> {
    String x;
    int y;

    public Classeai(String x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public int compareTo(Classeai o) {
        if(this.y < o.y)
            return 1;
        if(this.y > o.y)
            return -1;
        return 0;
    }



}

public class Filha2 extends Classeai{
    public Filha2(String x, int y) {
        super(x, y);
    }
}

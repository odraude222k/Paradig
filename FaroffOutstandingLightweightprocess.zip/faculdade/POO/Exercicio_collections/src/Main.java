import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        List<Classeai> listclasse = new ArrayList<>();
        Filha1 f1 = new Filha1("a ",2);
        Filha2 f2 = new Filha2("e ",8);
        Filha3 f3 = new Filha3("g ",6);

        listclasse.add(f1);
        listclasse.add(f2);
        listclasse.add(f3);

        Collections.sort(listclasse);

        for (Classeai classe : listclasse){
            System.out.println(classe.x + classe.y);
        }

    }
}
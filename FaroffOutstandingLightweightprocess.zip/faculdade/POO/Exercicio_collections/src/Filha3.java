public class Filha3 extends Classeai{

    public Filha3(String x, int y) {
        super(x, y);
    }
}

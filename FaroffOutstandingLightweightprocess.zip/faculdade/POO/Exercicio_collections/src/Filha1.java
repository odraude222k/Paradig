public class Filha1 extends Classeai{

    public Filha1(String x, int y) {
        super(x, y);
    }
}

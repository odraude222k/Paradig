//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Personagem personagem1 = new Personagem();
        Personagem personagem2 = new Personagem();

        personagem1.nome = "dudu";
        personagem1.pontos = 100;
        personagem2.nome = "ex";
        personagem2.pontos = 50;

        Arma arma1 = new Arma();
        personagem1.arma = arma1;

        Arma arma2 = new Arma();
        personagem2.arma = arma2;

        arma1.nome = "faca de serra";
        arma1.resistencia = 100;
        arma1.descricao = "Corta legal";

        arma2.nome = "gilette";
        arma2.resistencia = 75;
        arma2.descricao = "corta legal tambem";

        personagem1.usarArma();
        personagem2.tomarDano();
        personagem2.usarArma();
        personagem1.tomarDano();

        System.out.println("Vida do " + personagem1.nome + " " + personagem1.pontos);
        System.out.println("Vida do " + personagem2.nome + " " + personagem2.pontos);

        System.out.println("resistencia da arma" + " " + personagem1.nome + " " + personagem1.arma.resistencia);
        System.out.println("resistencia da arma"+ " " + personagem2.nome + " " + personagem2.arma.resistencia);




    }
}
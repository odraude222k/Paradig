public class App {
     Zumbi z1 = new Zumbi();
     Zumbi z2 = new Zumbi();








}

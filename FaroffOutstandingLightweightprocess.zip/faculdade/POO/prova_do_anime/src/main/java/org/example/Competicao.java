package org.example;

public class Competicao {
    private Musico[] competidores = new Musico[10];


    public void addMusico(Musico musico){
        for (int i = 0; i < competidores.length; i++){
            if(competidores[i] == null){
                competidores[i] = musico;
                break;
            }
        }
    }

    public void listarcompetidores(){
        for(int i = 0; i < competidores.length; i++){
            if (competidores[i] != null){
                if(competidores[i] instanceof Violinista){
                    Violinista vx = (Violinista) competidores[i];
                    vx.desafinar();
                    vx.tocar();
                    vx.mostraInfo();
                }
                if(competidores[i] instanceof Celista){
                    Celista cx = (Celista) competidores[i];
                    cx.desafinar();
                    cx.tocar();
                    cx.mostraInfo();
                }
                if(competidores[i] instanceof Pianista){
                    Pianista px = (Pianista) competidores[i];
                    px.tocar();
                    px.errarPausa();
                    px.tocarAcorde();
                    px.mostraInfo();
                }
            }
        }
    }
}

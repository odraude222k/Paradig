package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            Competicao comp = new Competicao();

            Violinista vio = new Violinista(1,"Dudu",20,"let it happen",100,"Yamaha",true);
            Celista cel = new Celista(2,"Gabriel",22,"Lux aeterna",100,true);
            Pianista pia = new Pianista(3,"Matheus",22,"bad guy",100,0.4f);

            comp.addMusico(pia);
            comp.addMusico(cel);
            comp.addMusico(vio);

            comp.listarcompetidores();

        }
    }

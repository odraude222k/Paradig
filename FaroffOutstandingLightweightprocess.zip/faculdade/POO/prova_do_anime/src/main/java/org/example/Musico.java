package org.example;

public abstract class Musico {

    protected static int contador = 0;
    protected int código;
    protected String nome;
    protected int idade;
    protected String musica;
    protected int pontuação;
    Instrumento instrumento;

    public Musico(int código, String nome, int idade, String musica, int pontuação,String modelo, Strin) {
        this.código = código;
        this.nome = nome;
        this.idade = idade;
        this.musica = musica;
        this.pontuação = pontuação;
        contador++;
    }

    public abstract void tocar();

    public void mostraInfo(){
        System.out.println("Código: " + this.código);
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Musica: " + this.musica);
        System.out.println("Pontuacao: " + this.pontuação);
    }
}


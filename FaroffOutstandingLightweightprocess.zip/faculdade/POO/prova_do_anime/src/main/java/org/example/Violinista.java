package org.example;

public class Violinista extends Musico implements Som{
    private String marcaBreu;
    private boolean usaEspaleira;

    public Violinista(int código, String nome, int idade, String musica, int pontuação, String marcaBreu, boolean usaEspaleira) {
        super(código, nome, idade, musica, pontuação);
        this.marcaBreu = marcaBreu;
        this.usaEspaleira = usaEspaleira;
    }

    @Override
    public void tocar(){
        System.out.println("Nome do violinista: " + this.nome);
        System.out.println("Nome da musica: " + this.musica);
    }

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("Marca do breu: " + this.marcaBreu);
        if(usaEspaleira){
            System.out.println("Usa espaleira");
        } else {
            System.out.println("Nao usa espaleira");
        }
    }

    @Override
    public void desafinar() {
        if(usaEspaleira){
            pontuação -= 0.1*pontuação;
        } else {
            pontuação -= 0.05*pontuação;
        }
    }
}

package org.example;

public class Celista extends Musico implements Som{
    private boolean sentado;

    public Celista(int código, String nome, int idade, String musica, int pontuação, boolean sentado) {
        super(código, nome, idade, musica, pontuação);
        this.sentado = sentado;
    }

    @Override
    public void tocar(){
        System.out.println("Nome do celista: " + this.nome);
        System.out.println("Nome da musica: " + this.musica);
    }

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        if(sentado){
            System.out.println("Toca sentado");
        } else {
            System.out.println("Toca em pé");
        }
    }

    @Override
    public void desafinar() {
        pontuação -= 0.05*pontuação;
    }
}

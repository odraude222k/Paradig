package org.example;

public interface Som {
    void desafinar();

}

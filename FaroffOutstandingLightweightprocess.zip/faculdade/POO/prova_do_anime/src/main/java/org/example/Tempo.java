package org.example;

public interface Tempo {
    void errarPausa();
}

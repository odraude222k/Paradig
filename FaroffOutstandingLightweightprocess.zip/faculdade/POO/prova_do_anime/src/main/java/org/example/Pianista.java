package org.example;

public class Pianista extends Musico implements Tecnica, Tempo{
    private float alturaBanco;

    public Pianista(int código, String nome, int idade, String musica, int pontuação, float alturaBanco) {
        super(código, nome, idade, musica, pontuação);
        this.alturaBanco = alturaBanco;
    }

    @Override
    public void tocar(){
        System.out.println("Nome do pianista: " + this.nome);
        System.out.println("Nome da musica: " + this.musica);
    }

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("Altura do Banco");
    }

    @Override
    public void tocarAcorde() {
        System.out.println("pianista tocou acorde");
    }

    @Override
    public void errarPausa() {
        pontuação -= 25;
        System.out.println("Musica vai recomecar");
    }
}

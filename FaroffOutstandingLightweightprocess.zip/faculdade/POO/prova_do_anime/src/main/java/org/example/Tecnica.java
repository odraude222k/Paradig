package org.example;

public interface Tecnica {
    void tocarAcorde();
}

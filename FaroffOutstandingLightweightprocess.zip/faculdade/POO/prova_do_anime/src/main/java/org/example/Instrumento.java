package org.example;

public class Instrumento {
    private String modelo;
    private String cor;
    private int ano;

}

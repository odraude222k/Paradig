public class Zumbi {

    double vida;
    String nome;

    double mostraVida(){

        return this.vida; //vida exclusivamente da classe que ela ta

    }

    boolean transfereVida (Zumbi zumbiAlvo, double quantia, Zumbi zumbicomido){

        if(zumbicomido.vida > quantia){
            zumbiAlvo.vida += quantia;
            zumbicomido.vida -= quantia;
            return true;
        } else {
            return false;
        }

    }
}

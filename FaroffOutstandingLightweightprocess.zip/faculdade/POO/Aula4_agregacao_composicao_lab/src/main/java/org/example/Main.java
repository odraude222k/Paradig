package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        int cv;


        Carro c1 = new Carro("fusca","vermelho",2000);
        Motor m1 = new Motor(80);



        System.out.println("nome do carro " + c1.nome);
        System.out.println("cor do carro " + c1.nome);
        System.out.println("ano do carro " + c1.nome);

        c1.motor = m1;

        System.out.println("motor do carro: " + c1.motor.cv);

        }
    }

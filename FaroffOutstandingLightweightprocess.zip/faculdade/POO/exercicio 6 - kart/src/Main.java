//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //alocando memoria para os pilotos
        Piloto piloto1 = new Piloto();
        Piloto piloto2 = new Piloto();

        // alocando memoria para os karts
        Kart kart1 = new Kart();
        Kart kart2 = new Kart();

        // associando piloto kart ao
        kart1.piloto = piloto1;
        kart2.piloto = piloto2;

        // colocando as informações
        piloto1.nome = "Carlos";
        piloto1.vilao = false;
        kart1.nome = "gol";
        kart1.mot.cilindradas = "150";
        kart1.mot.velocidademax = 120;

        piloto2.nome = "Joao";
        piloto2.vilao = true;
        kart2.nome = "polo";
        kart2.mot.cilindradas = "100";
        kart2.mot.velocidademax = 90;

        //acoes dos pilotos
        piloto1.soltaSuperPoder();
        piloto2.soltaSuperPoder();

        //acoes do kart1
        kart1.fazerDrift();
        kart1.mot.mostraInfo();

        //acoes do kart2
        kart2.soltarTurbo();
        kart2.mot.mostraInfo();





    }
}
public class Motor {
    String cilindradas;
    float velocidademax;

    void mostraInfo(){
        System.out.println("a cilindradas desse veiculo é: "+cilindradas);
        System.out.println("a velocidade maxima desse veiculo é: " + velocidademax);
    }
}

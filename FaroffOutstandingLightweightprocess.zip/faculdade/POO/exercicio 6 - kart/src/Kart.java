public class Kart {
    String nome;
    Motor mot;
    Piloto piloto;

    public Kart (){
        this.mot = new Motor();
    }
    void pular(){
        System.out.println(nome + " Acabou de pular");
    }

    void soltarTurbo(){
        System.out.println(nome + " Usou o turbo");
    }

    void fazerDrift() {
        System.out.println(nome + " Acabou de fazer um drift");
    }
}

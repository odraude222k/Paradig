public class Piloto {
    String nome;
    boolean vilao;
    Kart kart;

    void soltaSuperPoder(){
        System.out.println(nome + " esta soltando seu super poder");
    }
}

public class Cachorro extends Mamifero {

    public Cachorro(String nome, double vida) {
        super(nome, vida);
    }

    @Override
    public void emitirsom(){
        System.out.println("Cachorro emitindo som...");
    }
}

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Cachorro ca = new Cachorro("Maia",10);
        Lontra lo = new Lontra("Sarigue",50);
        Boi boi = new Boi("MUMU",1);

        ca.emitirsom();
        lo.emitirsom();
        boi.emitirsom();
        ca.mostraInfo();
        lo.mostraInfo();
        boi.mostraInfo();
    }
}
public class Lontra extends Mamifero implements Aquatico{
    public Lontra(String nome, double vida) {
        super(nome, vida);
    }
    @Override
    public void emitirsom(){
        System.out.println("Lontra emitindo som...");
    }

    @Override
    public void nadar(){
        System.out.println("lontra nadando.");
    }

}

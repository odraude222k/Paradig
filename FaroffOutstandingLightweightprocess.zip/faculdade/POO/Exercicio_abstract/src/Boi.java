public class Boi extends Mamifero {
    public Boi(String nome, double vida) {
        super(nome, vida);
    }

    @Override
    public void emitirsom(){
        System.out.println("Boi emitindo som...");
    }
}

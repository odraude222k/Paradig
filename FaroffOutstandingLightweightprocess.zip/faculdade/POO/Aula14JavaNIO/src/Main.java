import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Path arquivo = Paths.get("Professores.txt");

        try{
            List<String> professores = Files.readAllLines(arquivo);
            Map<String,String> aulas = new HashMap<>();

            professores.forEach((linha) -> {
                String[] linhaquebrada = linha.split("=");
                aulas.put(linhaquebrada[0], linhaquebrada[1].strip());
            });

            aulas.forEach((a,b) ->{
                System.out.println(a + " " + b);
            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
public class Main {
    public static void main(String[] args) {
        System.out.println("Inicio da main");

        Cliente c1 = new Cliente("C1", "E1", "111111");
        Cliente c2 = new Cliente("C2", "E2", "222222");
        Cliente c3 = null;

        Conta conta = new Conta(123, 5000, 4500);

        conta.addCliente(c1);
        conta.addCliente(c2);
        conta.addCliente(c3);

        conta.mostraInfo();

        System.out.println("Fim da main");
    }
}
import java.util.LinkedHashSet;
import java.util.Set;

public class Conta {
    private int numero;
    private float saldo;
    private float limite;
    private Set <Cliente> clientes = new LinkedHashSet<>();

    public Conta(int numero, float saldo, float limite) {
        this.numero = numero;
        this.saldo = saldo;
        this.limite = limite;
    }

    public void addCliente(Cliente novoCliente) {
        clientes.add(novoCliente);
    }

    public void mostraInfo() {
        System.out.println("Inicio do método 1");

        System.out.println("Saldo: " + this.saldo);
        System.out.println("Limite: " + this.limite);
        for (Cliente cliente : clientes){
            try {
                cliente.mostraInfo();
            } catch (NullPointerException e) {
                System.out.println("Erro " + e);
            }
        }

        System.out.println("Fim do método 1");
    }
}

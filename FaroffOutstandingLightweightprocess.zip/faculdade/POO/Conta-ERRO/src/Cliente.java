public class Cliente {
    private String nome;
    private String endereco;
    private String cpf;

    public Cliente(String nome, String endereco, String cpf) {
        this.nome = nome;
        this.endereco = endereco;
        this.cpf = cpf;
    }

    public void mostraInfo() {
        System.out.println("Inicio do método 2");

        System.out.println("Nome: " + this.nome);
        System.out.println("Endereço: " + this.endereco);
        System.out.println("CPF: " + this.cpf);

        System.out.println("Fim do método 2");
    }
}

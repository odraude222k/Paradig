import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Set<Integer> conjunto = new HashSet<>();
        List<Integer> conjunto1 = new ArrayList<>();
        Map<Integer,Integer> conjunto2 = new HashMap<>();
        int j = 0;

        long ti = System.currentTimeMillis();

        for(int i = 0; i < 100000;i++){
            conjunto.add(i);
        }
        long tf = System.currentTimeMillis();

        long tr = tf - ti;

        System.out.println("hashset: " + tr);

        long ti1 = System.currentTimeMillis();

        for(int i = 0; i < 100000;i++){
            conjunto1.add(i);
        }
        long tf1 = System.currentTimeMillis();

        long tr1 = tf1 - ti1;

        System.out.println("arraylist: " + tr1);

        long ti2 = System.currentTimeMillis();

        for(int i = 0; i < 100000;i++){
            conjunto2.put(j,i);
            j++;
        }
        long tf2 = System.currentTimeMillis();

        long tr2 = tf2 - ti2;

        System.out.println("map: " + tr2);

        //buscando hashset
        long tihashset = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++){
            conjunto.contains(i);
        }
        long tfhashset = System.currentTimeMillis();

        long trhashset = tfhashset - tihashset;

        System.out.println("Tempo para hashset: " + trhashset);

        //buscando para hashmap
        long tihashmap = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++){
            conjunto2.get(i);
        }
        long tfhashmap = System.currentTimeMillis();

        long trhashmap = tfhashmap - tihashmap;

        System.out.println("Tempo para busca hashmap: " + trhashmap);

        // buscando para arraylist
        tihashmap = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++){
            conjunto1.contains(i);
        }
        tfhashmap = System.currentTimeMillis();

        trhashmap = tfhashmap - tihashmap;

        System.out.println("Tempo para busca arraylist: " + trhashmap);
    }
}
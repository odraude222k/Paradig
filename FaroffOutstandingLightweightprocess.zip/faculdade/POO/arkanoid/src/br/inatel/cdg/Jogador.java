package br.inatel.cdg;

public class Jogador {
    private int ponto;
    Converte converte = new Converte();


    public int getPonto() {
        return ponto;
    }

    public void destruir(Bloco bloco){
        if(bloco.getNumerobloco() > 0){
            ponto++;
        }else {
            System.out.println("acabo, nao tem mais");
        }

    }
}

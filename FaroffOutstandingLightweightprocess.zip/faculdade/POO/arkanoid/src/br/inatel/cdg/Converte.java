package br.inatel.cdg;

public class Converte {
    private static int moeda;

    public static void conversor(Jogador jogador){
        moeda = jogador.getPonto()*100;
    }

}

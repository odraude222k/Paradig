package br.inatel.cdg;

public class Bloco {
    private static int numerobloco = 0;
    private static int blocodestroi = 0;
    private static int resto = 0;
    Jogador jogador = new Jogador();

    public int getNumerobloco() {
        return numerobloco;
    }

    public static void addBloco(int numerobloco) {
        numerobloco++;
    }

    public static void destroi(){
        blocodestroi++;
    }

    public static void restante(){
        resto = numerobloco - blocodestroi;
        System.out.println(resto);
    }


}

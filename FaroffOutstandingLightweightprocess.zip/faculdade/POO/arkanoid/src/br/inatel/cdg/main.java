package br.inatel.cdg;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bloco[] bloco = new Bloco[50];
        Jogador jogador = new Jogador();

        boolean flag = true;

        while(flag){
            System.out.println("1 - adicionar bloco");
            System.out.println("2 - destruir bloco");
            System.out.println("3- sair do programa");
            int op = sc.nextInt();

            switch (op){
                case 1:
                    Bloco.addBloco(1);
                    break;
                case 2:

            }
        }

    }
}

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        // criando instancia para cantina
        Cantina cantina = new Cantina();

        Salgado salgado1 = new Salgado();
        Salgado salgado2 = new Salgado();
        Salgado salgado3 = new Salgado();

        // entrando com os dados
        System.out.println("Adicione 3 salgados na cantina");
        salgado1.nome = entrada.nextLine();
        salgado2.nome = entrada.nextLine();
        salgado3.nome = entrada.nextLine();

        // adicionando salgado na cantina
        cantina.addSalgado(salgado1);
        cantina.addSalgado(salgado2);
        cantina.addSalgado(salgado3);

        cantina.mostraInfo();

        entrada.close();
    }
}
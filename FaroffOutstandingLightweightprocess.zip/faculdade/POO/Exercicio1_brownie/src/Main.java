import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BrownieNutella b1 = new BrownieNutella("dudu", 10,"nutella");
        BrownieDoceDeLeite b2 = new BrownieDoceDeLeite("sacani",8,"doce de leite");
        BrownieCafe b3 = new BrownieCafe("asus",7,"cafe");


        boolean flag = true;

        while (flag){
            System.out.println("1 - Nutella");
            System.out.println("2 - Doce de leite");
            System.out.println("3 - Cafe");
            int op = sc.nextInt();

            switch (op){
                case 1:
                    int aux;
                    b1.addCarrinhoDeCompras();
                    System.out.println("Deseja nutella extra? 1 - sim 2 - nao");
                    aux = sc.nextInt();
                    if(aux == 1){

                    }

            }
        }

    }
}
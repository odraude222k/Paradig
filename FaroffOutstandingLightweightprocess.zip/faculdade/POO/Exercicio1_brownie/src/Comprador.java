public class Comprador {

    private String nome;
    private double saldo = 150;

    public Comprador(String nome, double saldo) {
        this.nome = nome;
        this.saldo = saldo;
    }

    public void efetuarCompra(Brownie brownie){
        if(saldo >= brownie.preco  ){
            brownie.addCarrinhoDeCompras();
            brownie.calculaValorTotalDeCompra();

            saldo -= brownie.preco;
        }else {
            System.out.println("acabo, nao tem mais dinheiro");
        }
    }
}

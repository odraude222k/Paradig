package org.example;

public class Produto {

    //atributos do produto
    String nome;
    int nota;

    Fabricante fabricante;
    int quantidade;
    //construtor produto
    public Produto(String nome, int nota, String nomefabri, int cnpj, int quantidade) {
        this.nome = nome;
        this.nota = nota;
        this.fabricante = new Fabricante(nomefabri,cnpj);
        this.quantidade = quantidade;
    }

    public void mostrainfo(){
        System.out.println("Nome do produto: " + this.nome);
        System.out.println("Nota do produto: " + this.nota);
        System.out.println("qtd do produto: " + this.quantidade);
        System.out.println("Nome do fabricante: " + this.fabricante.nome);
        System.out.println("Cnpj do fabricante: " + this.fabricante.cnpj);
    }
}

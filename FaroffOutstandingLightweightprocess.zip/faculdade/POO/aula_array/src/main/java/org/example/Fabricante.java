package org.example;

public class Fabricante {
    // variaveis
    String nome;
    int cnpj;

    public Fabricante(String nome, int cnpj) {
        this.nome = nome;
        this.cnpj = cnpj;
    }


}

package org.example;

import javax.sound.midi.Soundbank;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Produto[] produtos = new Produto[10];
        Empresa e1 = new Empresa("JFL");

        Scanner sc = new Scanner(System.in);

        boolean flag = true;

        while (flag){
            System.out.println("---------------------------------------------");
            System.out.println("Bem-vindo ao menu de informacoes da empresa:");
            System.out.println("1 - Adicionar um produto a empresa.");
            System.out.println("2 - Mostrar as informacoes da empresa e do produto");
            System.out.println("3 - Sair do menu");

            int op = sc.nextInt();

            switch (op){
                case 1:
                    sc.nextLine();
                    System.out.println("Entre com o nome do produto: ");
                    String nomeprod = sc.nextLine();
                    System.out.println("Entre com a nota do produto");
                    int notaprod = sc.nextInt();
                    System.out.println("Entre com a quantidade do produto");
                    int qtdprod = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Entre com o fabricante do produto");
                    String nomefabri = sc.nextLine();
                    System.out.println("Entre com cnpj do fabricante do produto");
                    int cnpjfabri = sc.nextInt();

                    Produto p1 = new Produto(nomeprod,notaprod,nomefabri,cnpjfabri,qtdprod);
                    e1.adicionaProd(p1);
                    break;

                case 2:
                    e1.mostraInfo();
                    break;

                case 3:
                    flag = false;
                    break;
            }
        }


    }
}
package org.example;

public class Teste {

    static int contador=0;

    public Teste(){
        contador++;
        System.out.println("Teste numero " + contador);
    }
}

package org.example;

public class Funcionario {
    String nome;
    int id;
    private static int cont;

    public static int getCont() {
        return cont;
    }

    /*public static void setCont(int cont) {
        Funcionario.cont = cont;
    }*/

    public Funcionario(String nome){
        this.nome = nome;
        cont+=2;
        this.id = cont;
    }
}

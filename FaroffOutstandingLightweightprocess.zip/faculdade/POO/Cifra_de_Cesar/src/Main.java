import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String a;
        Scanner cin = new Scanner(System.in);
        a = cin.nextLine();
        StringBuilder textocript = new StringBuilder();


        Path arquivo = Paths.get("Frase.txt");

        for(int i = 0; i < a.length(); i++){
            textocript.append((char)(a.charAt(i) + 3));
        }


        try{
            Files.writeString(arquivo, textocript);

        }catch(IOException e){
            e.printStackTrace();
        }

        StringBuilder textoDescript = new StringBuilder();
        String frasealvoArq = null;

        try {
            frasealvoArq = Files.readString(arquivo);
        }catch(IOException e){
            e.printStackTrace();
        }

        for(int i = 0; i < frasealvoArq.length(); i++){
            textoDescript.append((char)(frasealvoArq.charAt(i) - 3));
        }
        System.out.println(frasealvoArq);
        System.out.println(textoDescript.toString());
    }
}
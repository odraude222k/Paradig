package org.example;

public class Main {
    public static void main(String[] args) {

        Funcionario[] funcs = new Funcionario[10];


        Engenheiro e = new Engenheiro("Gabriel", 22,500,"Computacao");
        Arquiteto a = new Arquiteto("Virginia", 20,500, "Casas");
        Professor p = new Professor("eduardo",20,700,"poo");

        funcs[0] = e;
        funcs[1] = a;
        funcs[2] = p;

        for (int i = 0; i < funcs.length; i++){
            if(funcs[i] != null){
                if(funcs[i] instanceof Engenheiro){
                    Engenheiro ex = (Engenheiro) funcs[i];
                    ex.executa();
                    ex.mostraInfo();
                }
                if(funcs[i] instanceof Arquiteto){
                    Arquiteto ax = (Arquiteto) funcs[i];
                    ax.executa();
                    ax.mostraInfo();
                }
                if(funcs[i] instanceof Professor){
                    Professor px = (Professor) funcs[i];
                    px.executa();
                    px.mostraInfo();
                }

            }
        }


    }
}
package org.example;

public class Arquiteto extends Funcionario{
    private String especialidade;


    public Arquiteto(String nome, int idade, float salario, String especialidade) {
        super(nome, idade, salario);
        this.especialidade = especialidade;
    }

    public String getEspecialidade(){
        return especialidade;
    }

    @Override
    public void executa(){
        System.out.println("O arquiteto esta planejando um predio");
    }

    @Override
    public void mostraInfo(){
        System.out.println("Informacoes do arquiteto");
        System.out.println("Nome do arquiteto: " + getNome());
        System.out.println("Idade do arquiteto: " + getIdade());
        System.out.println("Salario do arquiteto: " + getSalario());
        System.out.println("Especialidade: " + especialidade);
    }

    @Override
    public double salarioBonus(){
        return super.salarioBonus() +700;
    }
}

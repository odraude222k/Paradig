package org.example;

public class Professor extends Funcionario{
    private String materia;

    public Professor(String nome, int idade, float salario, String materia) {
        super(nome, idade, salario);
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    @Override
    public void executa(){
        System.out.println("O professor esta corrigindo prova");
    }

    @Override
    public void mostraInfo(){
        System.out.println("Informacoes do professor");
        System.out.println("Nome do professor: " + getNome());
        System.out.println("Idade do professor: " + getIdade());
        System.out.println("Salario do professor: " + getSalario());
        System.out.println("Materia do professor: " + materia);
    }
}

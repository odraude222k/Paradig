package org.example;

public class Engenheiro extends Funcionario implements Gerencia {

    private String ramo;

    public Engenheiro(String nome, int idade, float salario, String ramo) {
        super(nome, idade, salario);
        this.ramo = ramo;
    }

    @Override
    public void executa(){
        System.out.println("O engenheiro esta codando");
    }

    @Override
    public  void mostraInfo(){
        System.out.println("Informacoes do engenheiro");
        System.out.println("Nome do engenheiro: " + getNome());
        System.out.println("Idade do engenheiro: " + getIdade());
        System.out.println("Salario do engenheiro: " + getSalario());
        System.out.println("Ramo do engenheiro: " + ramo);
    }



    public String getRamo(){
        return ramo;
    }

    public void setRamo(String ramo) {
        this.ramo = ramo;
    }

    @Override
    public void gerencia(){
        System.out.println("O engenheiro gerencia");
    }

}

